var myApp = angular.module("myApp");

myApp.controller('DashboardController', ['$scope', '$http','$location', function($scope, $http,$location){
	console.log('Dashboard Controller Initialized...');
}]);